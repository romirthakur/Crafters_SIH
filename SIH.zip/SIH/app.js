const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");

const mongoURI = "mongodb://localhost:27017/Culture";

mongoose
  .connect(mongoURI)
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.log("MongoDB connection error: ", err));

app.set("view engine", "ejs");
app.set("views");
app.use(express.static("public"));

// Basic route for the home page
app.get("/", (req, res) => {
  res.render("home");
});
app.get("/food", (req, res) => {
  res.render("food");
});

// Define a port to listen on
const port = 8080;
// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
