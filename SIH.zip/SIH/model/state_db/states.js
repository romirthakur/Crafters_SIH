const mongoose = require("mongoose");
const Schema = new mongoose.Schema({
  state: {
    type: String,
    require: true,
    unique: true,
  },
  food: {
    type: String,
    require: true,
  },
  clothes: {
    type: String,
    require: true,
  },
  handmadearts: {
    type: String,
    require: true,
  },
  heritage: {
    type: String,
    require: true,
  },
});

//
const dbstate = mongoose.model("dbstate", Schema);
module.exports = dbstate;
