import express from "express";
const router = express.Router();
//

//
import { dbstate } from "../model/state_db/states";
router.get("/", (req, res) => {
  return res.render("index");
});

//
router.get("/food", async (req, res) => {
  return res.render("food");
});

//
router.get("/search", async (req, res) => {
  try {
    const query = req.query.q;
    const regex = new RegExp("^" + query, "i"); // Case-insensitive regex
    const museumName = await Museum.find({ name: { $regex: regex } }).limit(10);
    // res.render("main"); // Limit results
    res.send(museumName);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

export default router;
